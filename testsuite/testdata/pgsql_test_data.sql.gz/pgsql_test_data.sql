--
-- PostgreSQL database dump
--

-- Dumped from database version 12.8 (Ubuntu 12.8-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.8 (Ubuntu 12.8-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: planet_osm_line; Type: TABLE DATA; Schema: osm2pgsql_pgsql; Owner: -
--

INSERT INTO osm2pgsql_pgsql.planet_osm_line VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'motorway', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 39, NULL, '"foo"=>"bar", "highway"=>"motorway", "osm_uid"=>"1", "osm_user"=>"some_user", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0102000020E61000000300000000000000000000400000000000804840736891ED7C3F0340EC51B81E85CB484062427BE1D51D0540B6F044E127E04840');
INSERT INTO osm2pgsql_pgsql.planet_osm_line VALUES (6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'id_6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '"name"=>"id_6", "osm_uid"=>"1", "osm_user"=>"some_user", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0102000020E6100000020000000000000000000040000000000080484000000000000008400000000000804840');
INSERT INTO osm2pgsql_pgsql.planet_osm_line VALUES (6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'id_6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '"name"=>"id_6", "osm_uid"=>"1", "osm_user"=>"some_user", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0102000020E6100000020000000000000000000840000000000080484000000000000008400000000000004940');
INSERT INTO osm2pgsql_pgsql.planet_osm_line VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'motorway', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 39, NULL, '"foo"=>"bar", "highway"=>"motorway", "osm_uid"=>"1", "osm_user"=>"some_user", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0102000020E61000000200000062427BE1D51D0540B6F044E127E0484000000000000008400000000000004940');
INSERT INTO osm2pgsql_pgsql.planet_osm_line VALUES (6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'id_6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '"name"=>"id_6", "osm_uid"=>"1", "osm_user"=>"some_user", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0102000020E6100000020000000000000000000040000000000000494000000000000000400000000000804840');
INSERT INTO osm2pgsql_pgsql.planet_osm_line VALUES (6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'id_6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '"name"=>"id_6", "osm_uid"=>"1", "osm_user"=>"some_user", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0102000020E6100000020000000000000000000840000000000000494000000000000000400000000000004940');


--
-- Data for Name: planet_osm_nodes; Type: TABLE DATA; Schema: osm2pgsql_pgsql; Owner: -
--

INSERT INTO osm2pgsql_pgsql.planet_osm_nodes VALUES (1, 490000000, 20000000);
INSERT INTO osm2pgsql_pgsql.planet_osm_nodes VALUES (2, 500000000, 30000000);
INSERT INTO osm2pgsql_pgsql.planet_osm_nodes VALUES (3, 495000000, 30000000);
INSERT INTO osm2pgsql_pgsql.planet_osm_nodes VALUES (4, 490000000, 30000000);
INSERT INTO osm2pgsql_pgsql.planet_osm_nodes VALUES (5, 500000000, 20000000);
INSERT INTO osm2pgsql_pgsql.planet_osm_nodes VALUES (6, 491000000, 21000000);
INSERT INTO osm2pgsql_pgsql.planet_osm_nodes VALUES (7, 491000000, 22000000);
INSERT INTO osm2pgsql_pgsql.planet_osm_nodes VALUES (8, 492000000, 22000000);
INSERT INTO osm2pgsql_pgsql.planet_osm_nodes VALUES (9, 492000000, 21000000);
INSERT INTO osm2pgsql_pgsql.planet_osm_nodes VALUES (10, 495900000, 24060000);


--
-- Data for Name: planet_osm_point; Type: TABLE DATA; Schema: osm2pgsql_pgsql; Owner: -
--

INSERT INTO osm2pgsql_pgsql.planet_osm_point VALUES (3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Some interesting point', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '"bar"=>"baz", "foo"=>"bar", "name"=>"Some interesting point", "osm_uid"=>"1", "osm_user"=>"some_user", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0101000020E610000000000000000008400000000000C04840');
INSERT INTO osm2pgsql_pgsql.planet_osm_point VALUES (10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'traffic_signals', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Traffic light', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '"name"=>"Traffic light", "highway"=>"traffic_signals", "osm_uid"=>"1", "osm_user"=>"some_user", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2021-08-05T23:38:28Z"', '0101000020E6100000736891ED7C3F0340EC51B81E85CB4840');


--
-- Data for Name: planet_osm_polygon; Type: TABLE DATA; Schema: osm2pgsql_pgsql; Owner: -
--

INSERT INTO osm2pgsql_pgsql.planet_osm_polygon VALUES (3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0.01, '"area"=>"yes", "osm_uid"=>"1", "osm_user"=>"some_user", "way_area"=>"0.01", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0103000020E61000000100000005000000CDCCCCCCCCCC0040CDCCCCCCCC8C48409A99999999990140CDCCCCCCCC8C48409A999999999901409A99999999994840CDCCCCCCCCCC00409A99999999994840CDCCCCCCCCCC0040CDCCCCCCCC8C4840');
INSERT INTO osm2pgsql_pgsql.planet_osm_polygon VALUES (2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'wood', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, '"area"=>"yes", "natural"=>"wood", "osm_uid"=>"1", "osm_user"=>"some_user", "way_area"=>"1", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0103000020E610000001000000050000000000000000000040000000000080484000000000000008400000000000804840000000000000084000000000000049400000000000000040000000000000494000000000000000400000000000804840');
INSERT INTO osm2pgsql_pgsql.planet_osm_polygon VALUES (8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yes', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'standalone_polygon', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, '"area"=>"yes", "name"=>"standalone_polygon", "osm_uid"=>"1", "osm_user"=>"some_user", "way_area"=>"1", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0103000020E610000001000000050000000000000000000040000000000080484000000000000008400000000000804840000000000000084000000000000049400000000000000040000000000000494000000000000000400000000000804840');
INSERT INTO osm2pgsql_pgsql.planet_osm_polygon VALUES (-1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'forest', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0.99, '"natural"=>"forest", "osm_uid"=>"1", "osm_user"=>"some_user", "way_area"=>"0.99", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0103000020E61000000200000005000000000000000000004000000000008048400000000000000840000000000080484000000000000008400000000000004940000000000000004000000000000049400000000000000040000000000080484005000000CDCCCCCCCCCC0040CDCCCCCCCC8C4840CDCCCCCCCCCC00409A999999999948409A999999999901409A999999999948409A99999999990140CDCCCCCCCC8C4840CDCCCCCCCCCC0040CDCCCCCCCC8C4840');


--
-- Data for Name: planet_osm_rels; Type: TABLE DATA; Schema: osm2pgsql_pgsql; Owner: -
--

INSERT INTO osm2pgsql_pgsql.planet_osm_rels VALUES (1, 0, 2, '{2,3}', '{w2,outer,w3,inner}', '{type,multipolygon,natural,forest,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_rels VALUES (2, 0, 2, '{2,300}', '{w2,outer,w300,inner}', '{type,multipolygon,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_rels VALUES (3, 0, 1, '{1}', '{w1,""}', '{type,route,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_rels VALUES (4, 1, 2, '{1,1}', '{n1,"",w1,""}', '{type,other_type,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_rels VALUES (5, 0, 2, '{2,3}', '{w2,outer,w3,inner}', '{type,multipolygon,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');


--
-- Data for Name: planet_osm_roads; Type: TABLE DATA; Schema: osm2pgsql_pgsql; Owner: -
--

INSERT INTO osm2pgsql_pgsql.planet_osm_roads VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'motorway', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 39, NULL, '"foo"=>"bar", "highway"=>"motorway", "osm_uid"=>"1", "osm_user"=>"some_user", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0102000020E61000000300000000000000000000400000000000804840736891ED7C3F0340EC51B81E85CB484062427BE1D51D0540B6F044E127E04840');
INSERT INTO osm2pgsql_pgsql.planet_osm_roads VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'motorway', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 39, NULL, '"foo"=>"bar", "highway"=>"motorway", "osm_uid"=>"1", "osm_user"=>"some_user", "osm_version"=>"1", "osm_changeset"=>"1", "osm_timestamp"=>"2012-07-10T00:00:00Z"', '0102000020E61000000200000062427BE1D51D0540B6F044E127E0484000000000000008400000000000004940');


--
-- Data for Name: planet_osm_ways; Type: TABLE DATA; Schema: osm2pgsql_pgsql; Owner: -
--

INSERT INTO osm2pgsql_pgsql.planet_osm_ways VALUES (1, '{1,10,2}', '{highway,motorway,foo,bar,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_ways VALUES (2, '{1,4,2,5,1}', '{area,yes,natural,wood,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_ways VALUES (3, '{6,7,8,9,6}', '{area,yes,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_ways VALUES (4, '{600,700,800,900}', '{name,id_4,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_ways VALUES (5, '{1}', '{name,id_5,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_ways VALUES (6, '{1,4,2,5,900,1}', '{name,id_6,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_ways VALUES (7, '{1,2}', '{osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');
INSERT INTO osm2pgsql_pgsql.planet_osm_ways VALUES (8, '{1,4,2,5,1}', '{area,yes,name,standalone_polygon,osm_user,some_user,osm_uid,1,osm_version,1,osm_timestamp,2012-07-10T00:00:00Z,osm_changeset,1}');


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- PostgreSQL database dump complete
--

